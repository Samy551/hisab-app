package com.hisab.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.spacedBy
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.hisab.app.data.Debt
import com.hisab.app.data.HisabDao
import com.hisab.app.data.Repay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate

@Composable
fun DebtScreen(debts: List<Debt>, repays: List<Repay>, dao: HisabDao) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var person by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var given by remember { mutableStateOf(true) }
    var note by remember { mutableStateOf("") }
    var payFor by remember { mutableStateOf<Debt?>(null) }
    var toDel by remember { mutableStateOf<Debt?>(null) }

    val paid: Map<Long, Long> = repays.groupBy { it.debtId }
        .mapValues { e -> e.value.sumOf { it.amount } }
    val toReceive = debts.filter { it.isGiven }
        .sumOf { d -> (d.amount - (paid[d.id] ?: 0L)).coerceAtLeast(0L) }
    val toPay = debts.filter { !it.isGiven }
        .sumOf { d -> (d.amount - (paid[d.id] ?: 0L)).coerceAtLeast(0L) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("ادھار کا حساب", style = MaterialTheme.typography.titleMedium)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text("آپ کو لینا ہے: ${Fmt.rupees(toReceive)}")
                Text("آپ کو دینا ہے: ${Fmt.rupees(toPay)}")
            }
        }

        Text("نیا ادھار", style = MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = given, onClick = { given = true }, label = { Text("میں نے دیا") })
            FilterChip(selected = !given, onClick = { given = false }, label = { Text("میں نے لیا") })
        }
        OutlinedTextField(
            value = person,
            onValueChange = { person = it },
            label = { Text("کس کے ساتھ") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = amount,
            onValueChange = { amount = it.filter { c -> c.isDigit() } },
            label = { Text("رقم (روپے)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = note,
            onValueChange = { note = it },
            label = { Text("نوٹ (اختیاری)") },
            modifier = Modifier.fillMaxWidth()
        )
        Button(onClick = {
            val amt = amount.toLongOrNull()
            if (person.isBlank()) {
                toast(ctx, "نام لکھیں")
                return@Button
            }
            if (amt == null || amt <= 0L) {
                toast(ctx, "رقم درست لکھیں")
                return@Button
            }
            val d = Debt(
                person = person.trim(),
                isGiven = given,
                amount = amt,
                date = LocalDate.now().toString(),
                note = note.trim()
            )
            scope.launch(Dispatchers.IO) { dao.insertDebt(d) }
            person = ""
            amount = ""
            note = ""
        }) { Text("محفوظ کریں") }

        Text("فہرست", style = MaterialTheme.typography.labelLarge)
        if (debts.isEmpty()) Text("ابھی کوئی ادھار درج نہیں")
        debts.forEach { d ->
            val p = paid[d.id] ?: 0L
            val left = (d.amount - p).coerceAtLeast(0L)
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        "${d.person} · ${if (d.isGiven) "آپ نے دیا" else "آپ نے لیا"}",
                        style = MaterialTheme.typography.titleSmall
                    )
                    Text("اصل: ${Fmt.rupees(d.amount)} · واپس: ${Fmt.rupees(p)}")
                    Text("باقی: ${Fmt.rupees(left)}")
                    if (d.note.isNotBlank()) Text(d.note, style = MaterialTheme.typography.bodySmall)
                    Row {
                        TextButton(onClick = { payFor = d }) { Text("واپسی") }
                        TextButton(onClick = { toDel = d }) { Text("حذف") }
                    }
                }
            }
        }
    }

    payFor?.let { d ->
        RepayDialog(debt = d, dao = dao, onDismiss = { payFor = null })
    }

    toDel?.let { d ->
        AlertDialog(
            onDismissRequest = { toDel = null },
            title = { Text("ادھار حذف کریں؟") },
            text = { Text("${d.person} کا ریکارڈ اور اس کی سب واپسیاں ہٹ جائیں گی۔") },
            confirmButton = {
                TextButton(onClick = {
                    toDel = null
                    scope.launch(Dispatchers.IO) {
                        dao.deleteRepaysOf(d.id)
                        dao.deleteDebt(d.id)
                    }
                }) { Text("ہاں، حذف کریں") }
            },
            dismissButton = {
                TextButton(onClick = { toDel = null }) { Text("منسوخ") }
            }
        )
    }
}

@Composable
fun RepayDialog(debt: Debt, dao: HisabDao, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var amt by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("واپسی درج کریں") },
        text = {
            OutlinedTextField(
                value = amt,
                onValueChange = { amt = it.filter { c -> c.isDigit() } },
                label = { Text("رقم (روپے)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
        },
        confirmButton = {
            TextButton(onClick = {
                val v = amt.toLongOrNull()
                if (v == null || v <= 0L) {
                    toast(ctx, "رقم درست لکھیں")
                    return@TextButton
                }
                scope.launch(Dispatchers.IO) {
                    dao.insertRepay(Repay(debtId = debt.id, amount = v, date = LocalDate.now().toString()))
                }
                onDismiss()
            }) { Text("محفوظ کریں") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("منسوخ") }
        }
    )
}
