package com.hisab.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.spacedBy
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.hisab.app.data.Budget
import com.hisab.app.data.HisabDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun BudgetScreen(budgets: List<Budget>, dao: HisabDao) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var cat by remember { mutableStateOf(EXPENSE_CATEGORIES.first()) }
    var sc by remember { mutableStateOf(SCOPES.first()) }
    var limit by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("ماہانہ بجٹ", style = MaterialTheme.typography.titleMedium)
        Text(
            "ہر قسم کے لیے مہینے کی حد مقرر کریں۔ حد سے زیادہ خرچ پر ڈیش بورڈ میں نشان لگے گا۔",
            style = MaterialTheme.typography.bodySmall
        )

        Text("قسم", style = MaterialTheme.typography.labelLarge)
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            EXPENSE_CATEGORIES.forEach { c ->
                FilterChip(selected = cat == c, onClick = { cat = c }, label = { Text(c) })
            }
        }

        Text("کس کا خرچ", style = MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SCOPES.forEach { s ->
                FilterChip(selected = sc == s, onClick = { sc = s }, label = { Text(s) })
            }
        }

        OutlinedTextField(
            value = limit,
            onValueChange = { limit = it.filter { c -> c.isDigit() } },
            label = { Text("ماہانہ حد (روپے)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )

        Button(onClick = {
            val lim = limit.toLongOrNull()
            if (lim == null || lim <= 0L) {
                toast(ctx, "حد درست لکھیں")
                return@Button
            }
            val existing = budgets.find { it.category == cat && it.scope == sc }
            scope.launch(Dispatchers.IO) {
                if (existing != null) {
                    dao.updateBudget(existing.copy(monthlyLimit = lim))
                } else {
                    dao.insertBudget(Budget(category = cat, scope = sc, monthlyLimit = lim))
                }
            }
            limit = ""
        }) { Text("محفوظ کریں") }

        if (budgets.isEmpty()) Text("ابھی کوئی بجٹ مقرر نہیں")
        budgets.forEach { b ->
            Card(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("${b.category} (${b.scope})")
                        Text(
                            "ماہانہ حد: ${Fmt.rupees(b.monthlyLimit)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    TextButton(onClick = {
                        scope.launch(Dispatchers.IO) { dao.deleteBudget(b) }
                    }) { Text("حذف") }
                }
            }
        }
    }
}
