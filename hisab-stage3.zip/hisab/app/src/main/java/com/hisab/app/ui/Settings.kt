package com.hisab.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.spacedBy
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import com.hisab.app.security.AppLock

@Composable
fun SettingsDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var newPin by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf(AppLock.bioOn()) }
    var msg by remember { mutableStateOf("") }
    val pinSet = AppLock.pinSet()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ترتیبات") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (pinSet) "ایپ PIN سے لاک ہے" else "PIN لگانے سے ایپ لاک ہو سکتی ہے")
                OutlinedTextField(
                    value = newPin,
                    onValueChange = { newPin = it.filter { c -> c.isDigit() }.take(4) },
                    label = { Text("نیا 4 ہندسوں کا PIN") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                Button(onClick = {
                    if (newPin.length != 4) {
                        msg = "4 ہندسے لکھیں"
                    } else {
                        AppLock.setPin(newPin)
                        newPin = ""
                        msg = "PIN محفوظ ہو گیا"
                    }
                }) { Text("PIN محفوظ کریں") }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("فنگر پرنٹ سے کھولیں", modifier = Modifier.weight(1f))
                    Switch(
                        checked = bio,
                        enabled = pinSet && canUseBio(ctx),
                        onCheckedChange = {
                            bio = it
                            AppLock.setBio(it)
                        }
                    )
                }

                if (pinSet) {
                    TextButton(onClick = {
                        AppLock.clear()
                        msg = "لاک ہٹا دیا گیا"
                    }) { Text("لاک ہٹائیں") }
                }
                if (msg.isNotEmpty()) {
                    Text(msg, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("بند کریں") }
        }
    )
}
