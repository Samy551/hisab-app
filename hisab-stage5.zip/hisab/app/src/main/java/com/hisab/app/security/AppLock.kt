package com.hisab.app.security

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.security.MessageDigest

object AppLock {
    var locked by mutableStateOf(false)
    private lateinit var prefs: SharedPreferences

    fun init(ctx: Context) {
        prefs = ctx.applicationContext.getSharedPreferences("lock", Context.MODE_PRIVATE)
        locked = pinSet()
    }

    fun pinSet(): Boolean = ::prefs.isInitialized && prefs.contains("pin")

    fun bioOn(): Boolean = ::prefs.isInitialized && prefs.getBoolean("bio", false)

    fun setPin(pin: String) {
        prefs.edit().putString("pin", hash(pin)).apply()
    }

    fun checkPin(pin: String): Boolean = prefs.getString("pin", null) == hash(pin)

    fun setBio(on: Boolean) {
        prefs.edit().putBoolean("bio", on).apply()
    }

    fun clear() {
        prefs.edit().clear().apply()
        locked = false
    }

    fun onBackground() {
        if (pinSet()) locked = true
    }

    private fun hash(pin: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest(("hisab-v1|" + pin).toByteArray())
        return d.joinToString("") { "%02x".format(it) }
    }
}
