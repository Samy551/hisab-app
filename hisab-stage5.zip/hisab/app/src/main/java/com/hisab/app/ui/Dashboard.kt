package com.hisab.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.hisab.app.data.Budget
import com.hisab.app.data.Tx
import java.time.YearMonth

@Composable
fun DashboardScreen(
    items: List<Tx>,
    budgets: List<Budget>,
    onExport: () -> Unit,
    onImport: () -> Unit
) {
    var ym by remember { mutableStateOf(YearMonth.now()) }
    var scopeFilter by remember { mutableStateOf("سب") }
    val prefix = ym.toString()
    val monthAll = items.filter { it.date.startsWith(prefix) }
    val month = monthAll.filter { scopeFilter == "سب" || it.scope == scopeFilter }
    val income = month.filter { it.isIncome }.sumOf { it.amount }
    val expense = month.filter { !it.isIncome }.sumOf { it.amount }
    val byCat = month.filter { !it.isIncome }
        .groupBy { it.category }
        .map { (cat, list) -> cat to list.sumOf { it.amount } }
        .sortedByDescending { it.second }
    val budgetRows: List<Pair<Budget, Long>> = budgets
        .filter { scopeFilter == "سب" || it.scope == scopeFilter }
        .map { b ->
            val spent = monthAll
                .filter { !it.isIncome && it.category == b.category && it.scope == b.scope }
                .sumOf { it.amount }
            b to spent
        }
    val filters = listOf("سب") + SCOPES

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            TextButton(onClick = { ym = ym.minusMonths(1) }) { Text("◀ پچھلا") }
            Text(prefix, style = MaterialTheme.typography.titleMedium)
            TextButton(onClick = { ym = ym.plusMonths(1) }) { Text("اگلا ▶") }
        }

        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            filters.forEach { s ->
                FilterChip(
                    selected = scopeFilter == s,
                    onClick = { scopeFilter = s },
                    label = { Text(s) }
                )
            }
        }

        SummaryCard("آمدن", income, Color(0xFF1A7F37))
        SummaryCard("خرچ", expense, Color(0xFFC62828))
        SummaryCard("باقی بچت", income - expense, Color(0xFF1565C0))

        if (budgetRows.isNotEmpty()) {
            Text("ماہانہ بجٹ", style = MaterialTheme.typography.titleMedium)
            budgetRows.forEach { (b, spent) ->
                val over = spent > b.monthlyLimit
                val frac = if (b.monthlyLimit > 0L) {
                    (spent.toFloat() / b.monthlyLimit.toFloat()).coerceIn(0f, 1f)
                } else {
                    0f
                }
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${b.category} (${b.scope})")
                        Text(
                            "${Fmt.rupees(spent)} / ${Fmt.rupees(b.monthlyLimit)}",
                            color = if (over) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Box(
                        Modifier.fillMaxWidth().height(6.dp)
                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(3.dp))
                    ) {
                        Box(
                            Modifier.fillMaxWidth(frac).height(6.dp)
                                .background(
                                    if (over) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                                    RoundedCornerShape(3.dp)
                                )
                        )
                    }
                    if (over) {
                        Text(
                            "حد سے زیادہ خرچ ہو گیا",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        }

        Text("خرچ کی تفصیل", style = MaterialTheme.typography.titleMedium)
        if (byCat.isEmpty()) Text("اس مہینے کوئی خرچ نہیں")
        byCat.forEach { (cat, amt) ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(cat)
                Text(Fmt.rupees(amt))
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onExport) { Text("ایکسپورٹ") }
            OutlinedButton(onClick = onImport) { Text("امپورٹ") }
        }
        Text(
            "ایکسپورٹ کی فائل محفوظ جگہ رکھیں۔ نیا فون لیں تو امپورٹ سے ڈیٹا واپس لائیں۔",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
fun SummaryCard(title: String, value: Long, color: Color) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title)
            Text(Fmt.rupees(value), style = MaterialTheme.typography.headlineSmall, color = color)
        }
    }
}
