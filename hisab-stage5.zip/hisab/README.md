# حساب کتاب (Stage 5, version 1.4, versionCode 5)

- Fixed signing key (app/hisab-key.jks): future APKs install over this one. The first install of this version needs an uninstall of the old version (export data first).
- Payment method (کیش، کارڈ، اکاؤنٹ) on each entry, shown in the list.
- Search and scope filter in the list.
- Quick shortcuts (فوری شارٹ کٹ) in the entry form.
- Savings goals (بچت کا ہدف) with add-amount.
- Monthly recurring entries (ہر مہینے کے اندراجات), applied automatically once per month.
- Dark theme follows the phone setting.
- Database version 3 with a real migration (2 to 3). No data loss on upgrade from stage 3 or 4.
- NOT compiled in the chat. If the GitHub build fails, send the line that starts with "e: file:///".
