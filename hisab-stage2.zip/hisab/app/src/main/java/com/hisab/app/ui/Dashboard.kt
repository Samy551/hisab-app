package com.hisab.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.hisab.app.data.Tx
import java.time.YearMonth

@Composable
fun DashboardScreen(items: List<Tx>, onExport: () -> Unit, onImport: () -> Unit) {
    var ym by remember { mutableStateOf(YearMonth.now()) }
    val prefix = ym.toString()
    val month = items.filter { it.date.startsWith(prefix) }
    val income = month.filter { it.isIncome }.sumOf { it.amount }
    val expense = month.filter { !it.isIncome }.sumOf { it.amount }
    val byCat = month.filter { !it.isIncome }
        .groupBy { it.category }
        .map { (cat, list) -> cat to list.sumOf { it.amount } }
        .sortedByDescending { it.second }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            TextButton(onClick = { ym = ym.minusMonths(1) }) { Text("◀ پچھلا") }
            Text(prefix, style = MaterialTheme.typography.titleMedium)
            TextButton(onClick = { ym = ym.plusMonths(1) }) { Text("اگلا ▶") }
        }
        SummaryCard("آمدن", income, Color(0xFF1A7F37))
        SummaryCard("خرچ", expense, Color(0xFFC62828))
        SummaryCard("بچت", income - expense, Color(0xFF1565C0))

        Text("خرچ کی تفصیل", style = MaterialTheme.typography.titleMedium)
        if (byCat.isEmpty()) Text("اس مہینے کوئی خرچ نہیں")
        byCat.forEach { (cat, amt) ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(cat)
                Text(Fmt.rupees(amt))
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onExport) { Text("ایکسپورٹ") }
            OutlinedButton(onClick = onImport) { Text("امپورٹ") }
        }
        Text(
            "ایکسپورٹ کی فائل محفوظ جگہ رکھیں۔ نیا فون لیں تو امپورٹ سے ڈیٹا واپس لائیں۔",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
fun SummaryCard(title: String, value: Long, color: Color) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title)
            Text(Fmt.rupees(value), style = MaterialTheme.typography.headlineSmall, color = color)
        }
    }
}
