# حساب کتاب (Stage 1, version 1.1, versionCode 2)

- Room database (transactions table), Dashboard with month navigation, Add/Edit form, List with Edit and Delete.
- Export and import as JSON file (Storage Access Framework, no permissions needed).
- NOT compiled in the chat. If the GitHub build fails, send the line that starts with "e: file:///".
