package com.hisab.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.spacedBy
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.hisab.app.data.Tx

@Composable
fun ListScreen(list: List<Tx>, onEdit: (Tx) -> Unit, onDelete: (Tx) -> Unit) {
    if (list.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("ابھی کوئی اندراج نہیں")
        }
        return
    }
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(list, key = { it.id }) { tx ->
            val color = if (tx.isIncome) Color(0xFF1A7F37) else Color(0xFFC62828)
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(if (tx.isIncome) "آمدن" else "خرچ", color = color)
                        Text(Fmt.rupees(tx.amount), color = color)
                    }
                    Text("${tx.date} · ${tx.category}")
                    if (tx.note.isNotBlank()) Text(tx.note)
                    Row {
                        TextButton(onClick = { onEdit(tx) }) { Text("ترمیم") }
                        TextButton(onClick = { onDelete(tx) }) { Text("حذف") }
                    }
                }
            }
        }
    }
}
