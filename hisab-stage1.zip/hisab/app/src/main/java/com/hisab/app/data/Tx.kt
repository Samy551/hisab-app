package com.hisab.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "transactions")
data class Tx(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val date: String,
    val amount: Long,
    val isIncome: Boolean,
    val category: String,
    val note: String = ""
)

@Dao
interface TxDao {
    @Query("SELECT * FROM transactions ORDER BY date DESC, id DESC")
    fun all(): Flow<List<Tx>>

    @Query("SELECT * FROM transactions ORDER BY date DESC, id DESC")
    suspend fun allOnce(): List<Tx>

    @Insert
    suspend fun insert(tx: Tx): Long

    @Update
    suspend fun update(tx: Tx)

    @Delete
    suspend fun delete(tx: Tx)

    @Insert
    suspend fun insertAll(list: List<Tx>)

    @Query("DELETE FROM transactions")
    suspend fun clear()
}
