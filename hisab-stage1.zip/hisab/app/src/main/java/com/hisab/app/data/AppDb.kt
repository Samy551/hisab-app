package com.hisab.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Tx::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun txDao(): TxDao

    companion object {
        @Volatile
        private var instance: AppDb? = null

        fun get(context: Context): AppDb {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext, AppDb::class.java, "hisab.db"
                ).build().also { instance = it }
            }
        }
    }
}
