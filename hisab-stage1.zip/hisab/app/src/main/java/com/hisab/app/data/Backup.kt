package com.hisab.app.data

import android.content.Context
import android.net.Uri
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

object Backup {
    private val gson = Gson()

    fun backupTo(context: Context, uri: Uri, items: List<Tx>): Boolean {
        val json = gson.toJson(items)
        val out = context.contentResolver.openOutputStream(uri) ?: return false
        out.use { it.write(json.toByteArray(Charsets.UTF_8)) }
        return true
    }

    suspend fun restoreFrom(context: Context, uri: Uri, dao: TxDao): Int {
        val text = context.contentResolver.openInputStream(uri)
            ?.use { it.readBytes().toString(Charsets.UTF_8) } ?: return -1
        val type = object : TypeToken<List<Tx>>() {}.type
        val list: List<Tx>? = try {
            gson.fromJson(text, type)
        } catch (e: Exception) {
            null
        }
        if (list == null) return -1
        dao.clear()
        dao.insertAll(list.map { it.copy(id = 0L) })
        return list.size
    }
}
