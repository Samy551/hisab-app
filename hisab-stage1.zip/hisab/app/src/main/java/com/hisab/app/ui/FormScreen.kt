package com.hisab.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.spacedBy
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.hisab.app.data.Tx
import com.hisab.app.data.TxDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

@Composable
fun FormScreen(dao: TxDao, editing: Tx?, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var date by remember(editing) { mutableStateOf(editing?.date ?: LocalDate.now().toString()) }
    var amount by remember(editing) { mutableStateOf(editing?.amount?.toString() ?: "") }
    var isIncome by remember(editing) { mutableStateOf(editing?.isIncome ?: false) }
    var category by remember(editing) { mutableStateOf(editing?.category ?: "") }
    var note by remember(editing) { mutableStateOf(editing?.note ?: "") }
    val cats = if (isIncome) INCOME_CATEGORIES else EXPENSE_CATEGORIES

    Column(
        Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            if (editing == null) "نیا اندراج" else "اندراج میں ترمیم",
            style = MaterialTheme.typography.titleMedium
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = !isIncome,
                onClick = { isIncome = false; category = "" },
                label = { Text("خرچ") }
            )
            FilterChip(
                selected = isIncome,
                onClick = { isIncome = true; category = "" },
                label = { Text("آمدن") }
            )
        }

        OutlinedTextField(
            value = date,
            onValueChange = { date = it },
            label = { Text("تاریخ (مثلاً 2026-11-24)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = amount,
            onValueChange = { amount = it.filter { c -> c.isDigit() } },
            label = { Text("رقم (روپے)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )

        Text("قسم", style = MaterialTheme.typography.labelLarge)
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            cats.forEach { c ->
                FilterChip(
                    selected = category == c,
                    onClick = { category = c },
                    label = { Text(c) }
                )
            }
        }

        OutlinedTextField(
            value = category,
            onValueChange = { category = it },
            label = { Text("قسم (خود لکھیں)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = note,
            onValueChange = { note = it },
            label = { Text("نوٹ (اختیاری)") },
            modifier = Modifier.fillMaxWidth()
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                val d = runCatching { LocalDate.parse(date.trim()).toString() }.getOrNull()
                val amt = amount.trim().toLongOrNull()
                val cat = category.trim()
                if (d == null) {
                    toast(ctx, "تاریخ درست لکھیں، مثلاً 2026-11-24")
                    return@Button
                }
                if (amt == null || amt <= 0L) {
                    toast(ctx, "رقم درست لکھیں")
                    return@Button
                }
                if (cat.isEmpty()) {
                    toast(ctx, "قسم لکھیں یا چنیں")
                    return@Button
                }
                val tx = Tx(
                    id = editing?.id ?: 0L,
                    date = d,
                    amount = amt,
                    isIncome = isIncome,
                    category = cat,
                    note = note.trim()
                )
                scope.launch(Dispatchers.IO) {
                    if (editing == null) dao.insert(tx) else dao.update(tx)
                    withContext(Dispatchers.Main) { onDone() }
                }
            }) { Text("محفوظ کریں") }

            if (editing != null) {
                OutlinedButton(onClick = onDone) { Text("منسوخ") }
            }
        }
    }
}
