# حساب کتاب (Stage 3, version 1.2, versionCode 3)

- Dashboard with month navigation, scope filter (ذاتی, گھر, کاروبار), monthly budget bars.
- Entry form with scope chips. Debts (ادھار) with repayments. Monthly budgets per category and scope.
- Fingerprint lock (BiometricPrompt) with a 4-digit PIN as backup. Lock when leaving the app.
- Export and import (JSON). Old list-format backups from stage 1 can be imported.
- Database version 2 uses destructive migration: export the old data before installing.
- NOT compiled in the chat. If the GitHub build fails, send the line that starts with "e: file:///".
