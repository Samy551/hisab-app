package com.hisab.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface HisabDao {
    @Query("SELECT * FROM transactions ORDER BY date DESC, id DESC")
    fun txFlow(): Flow<List<Tx>>

    @Query("SELECT * FROM transactions ORDER BY date DESC, id DESC")
    suspend fun txOnce(): List<Tx>

    @Insert
    suspend fun insertTx(tx: Tx): Long

    @Update
    suspend fun updateTx(tx: Tx)

    @Delete
    suspend fun deleteTx(tx: Tx)

    @Insert
    suspend fun insertTxs(list: List<Tx>)

    @Query("DELETE FROM transactions")
    suspend fun clearTx()

    @Query("SELECT * FROM budgets")
    fun budgetFlow(): Flow<List<Budget>>

    @Query("SELECT * FROM budgets")
    suspend fun budgetOnce(): List<Budget>

    @Insert
    suspend fun insertBudget(b: Budget): Long

    @Update
    suspend fun updateBudget(b: Budget)

    @Delete
    suspend fun deleteBudget(b: Budget)

    @Insert
    suspend fun insertBudgets(list: List<Budget>)

    @Query("DELETE FROM budgets")
    suspend fun clearBudgets()

    @Query("SELECT * FROM debts ORDER BY date DESC, id DESC")
    fun debtFlow(): Flow<List<Debt>>

    @Query("SELECT * FROM debts")
    suspend fun debtOnce(): List<Debt>

    @Insert
    suspend fun insertDebt(d: Debt): Long

    @Insert
    suspend fun insertDebts(list: List<Debt>)

    @Query("DELETE FROM debts WHERE id = :id")
    suspend fun deleteDebt(id: Long)

    @Query("DELETE FROM debts")
    suspend fun clearDebts()

    @Query("SELECT * FROM repays ORDER BY date DESC, id DESC")
    fun repayFlow(): Flow<List<Repay>>

    @Query("SELECT * FROM repays")
    suspend fun repayOnce(): List<Repay>

    @Insert
    suspend fun insertRepay(r: Repay): Long

    @Insert
    suspend fun insertRepays(list: List<Repay>)

    @Query("DELETE FROM repays WHERE debtId = :debtId")
    suspend fun deleteRepaysOf(debtId: Long)

    @Query("DELETE FROM repays")
    suspend fun clearRepays()
}
