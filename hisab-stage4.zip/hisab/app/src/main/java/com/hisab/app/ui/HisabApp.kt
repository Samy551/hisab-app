package com.hisab.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.hisab.app.data.AppDb
import com.hisab.app.data.Backup
import com.hisab.app.data.Tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HisabApp() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { AppDb.get(ctx).dao() }
    val items by dao.txFlow().collectAsState(initial = emptyList())
    val budgets by dao.budgetFlow().collectAsState(initial = emptyList())
    val debts by dao.debtFlow().collectAsState(initial = emptyList())
    val repays by dao.repayFlow().collectAsState(initial = emptyList())
    var tab by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<Tx?>(null) }
    var toDelete by remember { mutableStateOf<Tx?>(null) }
    var askImport by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                val ok = Backup.backupTo(ctx, uri, dao)
                withContext(Dispatchers.Main) {
                    toast(ctx, if (ok) "ڈیٹا محفوظ ہو گیا" else "محفوظ نہیں ہو سکا")
                }
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                val n = Backup.restoreFrom(ctx, uri, dao)
                withContext(Dispatchers.Main) {
                    toast(ctx, if (n >= 0) "$n اندراج امپورٹ ہو گئے" else "فائل درست نہیں ہے")
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("حساب کتاب") },
                actions = {
                    TextButton(onClick = { showSettings = true }) { Text("⚙") }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0, onClick = { tab = 0 },
                    icon = { Text("📊") }, label = { Text("خلاصہ") }
                )
                NavigationBarItem(
                    selected = tab == 1, onClick = { editing = null; tab = 1 },
                    icon = { Text("➕") }, label = { Text("نیا") }
                )
                NavigationBarItem(
                    selected = tab == 2, onClick = { tab = 2 },
                    icon = { Text("📋") }, label = { Text("فہرست") }
                )
                NavigationBarItem(
                    selected = tab == 3, onClick = { tab = 3 },
                    icon = { Text("🤝") }, label = { Text("ادھار") }
                )
                NavigationBarItem(
                    selected = tab == 4, onClick = { tab = 4 },
                    icon = { Text("🎯") }, label = { Text("بجٹ") }
                )
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> DashboardScreen(
                    items = items,
                    budgets = budgets,
                    onExport = { exportLauncher.launch("hisab-backup.json") },
                    onImport = { askImport = true }
                )
                1 -> FormScreen(dao = dao, editing = editing) { editing = null; tab = 2 }
                2 -> ListScreen(
                    list = items,
                    onEdit = { editing = it; tab = 1 },
                    onDelete = { toDelete = it }
                )
                3 -> DebtScreen(debts = debts, repays = repays, dao = dao)
                else -> BudgetScreen(budgets = budgets, dao = dao)
            }
        }
    }

    toDelete?.let { tx ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("حذف کریں؟") },
            text = { Text("${tx.date} · ${Fmt.rupees(tx.amount)} · ${tx.category}") },
            confirmButton = {
                TextButton(onClick = {
                    toDelete = null
                    scope.launch(Dispatchers.IO) { dao.deleteTx(tx) }
                }) { Text("ہاں، حذف کریں") }
            },
            dismissButton = {
                TextButton(onClick = { toDelete = null }) { Text("منسوخ") }
            }
        )
    }

    if (askImport) {
        AlertDialog(
            onDismissRequest = { askImport = false },
            title = { Text("امپورٹ کریں؟") },
            text = { Text("موجودہ سارا ڈیٹا بدل جائے گا۔ پہلے ایکسپورٹ کر لیں۔") },
            confirmButton = {
                TextButton(onClick = {
                    askImport = false
                    importLauncher.launch(arrayOf("*/*"))
                }) { Text("جاری رکھیں") }
            },
            dismissButton = {
                TextButton(onClick = { askImport = false }) { Text("منسوخ") }
            }
        )
    }

    if (showSettings) {
        SettingsDialog(onDismiss = { showSettings = false })
    }
}
