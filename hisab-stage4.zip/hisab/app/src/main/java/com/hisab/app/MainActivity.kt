package com.hisab.app

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.fragment.app.FragmentActivity
import com.hisab.app.security.AppLock
import com.hisab.app.ui.HisabApp
import com.hisab.app.ui.LockScreen

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLock.init(this)
        setContent {
            MaterialTheme {
                Root()
            }
        }
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) AppLock.onBackground()
    }
}

@Composable
fun Root() {
    if (AppLock.locked) LockScreen() else HisabApp()
}
