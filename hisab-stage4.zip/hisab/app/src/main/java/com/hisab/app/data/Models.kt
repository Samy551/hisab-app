package com.hisab.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class Tx(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val date: String,
    val amount: Long,
    val isIncome: Boolean,
    val category: String,
    val scope: String = "ذاتی",
    val note: String = ""
)

@Entity(tableName = "budgets")
data class Budget(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val category: String,
    val scope: String,
    val monthlyLimit: Long
)

@Entity(tableName = "debts")
data class Debt(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val person: String,
    val isGiven: Boolean,
    val amount: Long,
    val date: String,
    val note: String = ""
)

@Entity(tableName = "repays")
data class Repay(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val debtId: Long,
    val amount: Long,
    val date: String
)
