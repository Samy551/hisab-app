package com.hisab.app.data

import android.content.Context
import android.net.Uri
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

data class BackupData(
    val txs: List<Tx>? = null,
    val budgets: List<Budget>? = null,
    val debts: List<Debt>? = null,
    val repays: List<Repay>? = null
)

object Backup {
    private val gson = Gson()

    suspend fun backupTo(context: Context, uri: Uri, dao: HisabDao): Boolean {
        val data = BackupData(dao.txOnce(), dao.budgetOnce(), dao.debtOnce(), dao.repayOnce())
        val json = gson.toJson(data)
        val out = context.contentResolver.openOutputStream(uri) ?: return false
        out.use { it.write(json.toByteArray(Charsets.UTF_8)) }
        return true
    }

    suspend fun restoreFrom(context: Context, uri: Uri, dao: HisabDao): Int {
        val text = context.contentResolver.openInputStream(uri)
            ?.use { it.readBytes().toString(Charsets.UTF_8) } ?: return -1
        val trimmed = text.trim()
        val data: BackupData = try {
            if (trimmed.startsWith("[")) {
                val type = object : TypeToken<List<Tx>>() {}.type
                val list: List<Tx> = gson.fromJson(trimmed, type)
                BackupData(txs = list)
            } else {
                gson.fromJson(trimmed, BackupData::class.java)
            }
        } catch (e: Exception) {
            return -1
        }
        val txs = (data.txs ?: emptyList()).map { t ->
            if (t.scope.isNullOrBlank()) t.copy(scope = "ذاتی") else t
        }
        dao.clearTx()
        dao.clearBudgets()
        dao.clearDebts()
        dao.clearRepays()
        dao.insertTxs(txs)
        dao.insertBudgets(data.budgets ?: emptyList())
        dao.insertDebts(data.debts ?: emptyList())
        dao.insertRepays(data.repays ?: emptyList())
        return txs.size
    }
}
