package com.hisab.app.ui

import android.content.Context
import android.widget.Toast

val SCOPES = listOf("ذاتی", "گھر", "کاروبار")
val EXPENSE_CATEGORIES = listOf("کھانا", "بل", "کرایہ", "سفر", "صحت", "تعلیم", "کپڑے", "دیگر")
val INCOME_CATEGORIES = listOf("تنخواہ", "کاروبار", "تحفہ", "دیگر")

object Fmt {
    fun rupees(v: Long): String = String.format("%,d", v) + " روپے"
}

fun toast(ctx: Context, msg: String) {
    Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
}
