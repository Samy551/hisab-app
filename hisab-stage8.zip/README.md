# حساب کتاب (Stage 5, version 1.4, versionCode 5)

- Fixed signing key (app/hisab-key.jks): future APKs install over this one. The first install of this version needs an uninstall of the old version (export data first).
- Payment method (کیش، کارڈ، اکاؤنٹ) on each entry, shown in the list.
- Search and scope filter in the list.
- Quick shortcuts (فوری شارٹ کٹ) in the entry form.
- Savings goals (بچت کا ہدف) with add-amount.
- Monthly recurring entries (ہر مہینے کے اندراجات), applied automatically once per month.
- Dark theme follows the phone setting.
- Database version 3 with a real migration (2 to 3). No data loss on upgrade from stage 3 or 4.
- NOT compiled in the chat. If the GitHub build fails, send the line that starts with "e: file:///".

## Stage 7 (version 1.5, versionCode 6)
- PDF monthly report (PDF رپورٹ) from the dashboard: totals, category totals, budgets, all entries of the month.
- Category bars in the dashboard for expenses.

## Stage 8 (version 1.6, versionCode 7)
- گھر نقد (Home cash) tab: cash given at home, with who received it, date and note. Monthly total and per-person totals.
- Dashboard shows "گھر میں نقد دیا" for the month. It is kept separate from expenses, so it is not counted twice.
- PDF monthly report includes the home cash total and the list of home cash entries.
- Language switch in Settings (ترتیبات): اردو / English. Every label, category and PDF text is translated. Stored data stays as entered.
- Database version 4, with a real migration (3 to 4). Backups include home cash. Older backups still import.
- Signing key unchanged: install over stage 7 normally, no uninstall needed.
- NOT compiled in the chat. If the GitHub build fails, send the line that starts with "e: file:///".

English summary: Stage 8 adds a Home cash tab (cash given at home, monthly totals, PDF line), an Urdu/English language switch in Settings, and database version 4 with migration from 3. Version 1.6 (versionCode 7).
