package com.hisab.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface HisabDao {
    @Query("SELECT * FROM transactions ORDER BY date DESC, id DESC")
    fun txFlow(): Flow<List<Tx>>

    @Query("SELECT * FROM transactions ORDER BY date DESC, id DESC")
    suspend fun txOnce(): List<Tx>

    @Insert
    suspend fun insertTx(tx: Tx): Long

    @Update
    suspend fun updateTx(tx: Tx)

    @Delete
    suspend fun deleteTx(tx: Tx)

    @Insert
    suspend fun insertTxs(list: List<Tx>)

    @Query("DELETE FROM transactions")
    suspend fun clearTx()

    @Query("SELECT * FROM budgets")
    fun budgetFlow(): Flow<List<Budget>>

    @Query("SELECT * FROM budgets")
    suspend fun budgetOnce(): List<Budget>

    @Insert
    suspend fun insertBudget(b: Budget): Long

    @Update
    suspend fun updateBudget(b: Budget)

    @Delete
    suspend fun deleteBudget(b: Budget)

    @Insert
    suspend fun insertBudgets(list: List<Budget>)

    @Query("DELETE FROM budgets")
    suspend fun clearBudgets()

    @Query("SELECT * FROM debts ORDER BY date DESC, id DESC")
    fun debtFlow(): Flow<List<Debt>>

    @Query("SELECT * FROM debts")
    suspend fun debtOnce(): List<Debt>

    @Insert
    suspend fun insertDebt(d: Debt): Long

    @Insert
    suspend fun insertDebts(list: List<Debt>)

    @Query("DELETE FROM debts WHERE id = :id")
    suspend fun deleteDebt(id: Long)

    @Query("DELETE FROM debts")
    suspend fun clearDebts()

    @Query("SELECT * FROM repays ORDER BY date DESC, id DESC")
    fun repayFlow(): Flow<List<Repay>>

    @Query("SELECT * FROM repays")
    suspend fun repayOnce(): List<Repay>

    @Insert
    suspend fun insertRepay(r: Repay): Long

    @Insert
    suspend fun insertRepays(list: List<Repay>)

    @Query("DELETE FROM repays WHERE debtId = :debtId")
    suspend fun deleteRepaysOf(debtId: Long)

    @Query("DELETE FROM repays")
    suspend fun clearRepays()

    @Query("SELECT * FROM goals ORDER BY id DESC")
    fun goalFlow(): Flow<List<Goal>>

    @Query("SELECT * FROM goals")
    suspend fun goalOnce(): List<Goal>

    @Insert
    suspend fun insertGoal(g: Goal): Long

    @Update
    suspend fun updateGoal(g: Goal)

    @Query("DELETE FROM goals WHERE id = :id")
    suspend fun deleteGoal(id: Long)

    @Insert
    suspend fun insertGoals(list: List<Goal>)

    @Query("DELETE FROM goals")
    suspend fun clearGoals()

    @Query("SELECT * FROM recurring ORDER BY id DESC")
    fun recurFlow(): Flow<List<Recurring>>

    @Query("SELECT * FROM recurring")
    suspend fun recurOnce(): List<Recurring>

    @Insert
    suspend fun insertRecur(r: Recurring): Long

    @Update
    suspend fun updateRecur(r: Recurring)

    @Query("DELETE FROM recurring WHERE id = :id")
    suspend fun deleteRecur(id: Long)

    @Insert
    suspend fun insertRecurs(list: List<Recurring>)

    @Update
    suspend fun updateRecurSimple(r: Recurring)

    @Query("DELETE FROM recurring")
    suspend fun clearRecurs()

    @Query("SELECT * FROM presets ORDER BY id DESC")
    fun presetFlow(): Flow<List<Preset>>

    @Query("SELECT * FROM presets")
    suspend fun presetOnce(): List<Preset>

    @Insert
    suspend fun insertPreset(p: Preset): Long

    @Query("DELETE FROM presets WHERE id = :id")
    suspend fun deletePreset(id: Long)

    @Insert
    suspend fun insertPresets(list: List<Preset>)

    @Query("DELETE FROM presets")
    suspend fun clearPresets()

    @Query("SELECT * FROM home_cash ORDER BY date DESC, id DESC")
    fun homeCashFlow(): Flow<List<HomeCash>>

    @Query("SELECT * FROM home_cash")
    suspend fun homeCashOnce(): List<HomeCash>

    @Insert
    suspend fun insertHomeCash(h: HomeCash): Long

    @Insert
    suspend fun insertHomeCashes(list: List<HomeCash>)

    @Query("DELETE FROM home_cash WHERE id = :id")
    suspend fun deleteHomeCash(id: Long)

    @Query("DELETE FROM home_cash")
    suspend fun clearHomeCash()
}
