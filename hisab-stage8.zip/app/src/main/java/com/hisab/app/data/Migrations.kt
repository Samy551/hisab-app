package com.hisab.app.data

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE transactions ADD COLUMN payment TEXT")
        db.execSQL("CREATE TABLE IF NOT EXISTS goals (id INTEGER NOT NULL PRIMARY KEY, name TEXT NOT NULL, target INTEGER NOT NULL, saved INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS recurring (id INTEGER NOT NULL PRIMARY KEY, category TEXT NOT NULL, scope TEXT NOT NULL, amount INTEGER NOT NULL, note TEXT NOT NULL, lastApplied TEXT NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS presets (id INTEGER NOT NULL PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL, scope TEXT NOT NULL, amount INTEGER NOT NULL, payment TEXT NOT NULL)")
    }
}

val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS home_cash (id INTEGER NOT NULL PRIMARY KEY, date TEXT NOT NULL, amount INTEGER NOT NULL, person TEXT NOT NULL, note TEXT NOT NULL)")
    }
}
