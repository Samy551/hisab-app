package com.hisab.app.ui

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.material3.Text as M3Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle

object Lang {
    var en by mutableStateOf(false)
    private var prefs: SharedPreferences? = null

    fun init(ctx: Context) {
        prefs = ctx.applicationContext.getSharedPreferences("prefs", Context.MODE_PRIVATE)
        en = prefs?.getBoolean("english", false) ?: false
    }

    fun set(english: Boolean) {
        en = english
        prefs?.edit()?.putBoolean("english", english)?.apply()
    }
}

// Stored data (categories, scopes, payments) stays in Urdu; only the display is translated.
fun tr(s: String): String = if (Lang.en) (EN[s] ?: s) else s

// Every Text in the app goes through here, so labels switch language automatically.
@Composable
fun Text(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    style: TextStyle? = null
) {
    val shown = tr(text)
    if (style == null) {
        M3Text(text = shown, modifier = modifier, color = color)
    } else {
        M3Text(text = shown, modifier = modifier, color = color, style = style)
    }
}
