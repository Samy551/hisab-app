package com.hisab.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.hisab.app.data.Tx

@Composable
fun ListScreen(list: List<Tx>, onEdit: (Tx) -> Unit, onDelete: (Tx) -> Unit) {
    var query by remember { mutableStateOf("") }
    var scopeFilter by remember { mutableStateOf("سب") }
    if (list.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("ابھی کوئی اندراج نہیں")
        }
        return
    }
    val q = query.trim()
    val shown = list.filter { tx ->
        (scopeFilter == "سب" || tx.scope == scopeFilter) &&
            (q.isEmpty() || listOf(tx.category, tx.note, tx.date, tx.amount.toString(), tx.payment ?: "")
                .any { it.contains(q, ignoreCase = true) })
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("تلاش (قسم، نوٹ، تاریخ، رقم)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            (listOf("سب") + SCOPES).forEach { s ->
                FilterChip(
                    selected = scopeFilter == s,
                    onClick = { scopeFilter = s },
                    label = { Text(s) }
                )
            }
        }
        if (shown.isEmpty()) Text("کوئی اندراج نہیں ملا")
        LazyColumn(
            Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 8.dp)
        ) {
            items(shown, key = { it.id }) { tx ->
                val color = if (tx.isIncome) Color(0xFF1A7F37) else Color(0xFFC62828)
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(if (tx.isIncome) "آمدن" else "خرچ", color = color)
                            Text(Fmt.rupees(tx.amount), color = color)
                        }
                        Text("${tx.date} · ${tr(tx.category)} · ${tr(tx.scope)} · ${tr(tx.payment ?: "کیش")}")
                        if (tx.note.isNotBlank()) Text(tx.note)
                        Row {
                            TextButton(onClick = { onEdit(tx) }) { Text("ترمیم") }
                            TextButton(onClick = { onDelete(tx) }) { Text("حذف") }
                        }
                    }
                }
            }
        }
    }
}
