package com.hisab.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.hisab.app.data.Budget
import com.hisab.app.data.Goal
import com.hisab.app.data.HisabDao
import com.hisab.app.data.Preset
import com.hisab.app.data.Recurring
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun BudgetScreen(
    budgets: List<Budget>,
    goals: List<Goal>,
    recurring: List<Recurring>,
    presets: List<Preset>,
    dao: HisabDao
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var cat by remember { mutableStateOf(EXPENSE_CATEGORIES.first()) }
    var sc by remember { mutableStateOf(SCOPES.first()) }
    var limit by remember { mutableStateOf("") }
    var goalName by remember { mutableStateOf("") }
    var goalTarget by remember { mutableStateOf("") }
    var recName by remember { mutableStateOf("") }
    var recAmount by remember { mutableStateOf("") }
    var recCat by remember { mutableStateOf(EXPENSE_CATEGORIES.first()) }
    var recScope by remember { mutableStateOf(SCOPES.first()) }
    var addTo by remember { mutableStateOf<Goal?>(null) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("ماہانہ بجٹ", style = MaterialTheme.typography.titleMedium)
        Text(
            "ہر قسم کے لیے مہینے کی حد مقرر کریں۔ حد سے زیادہ خرچ پر ڈیش بورڈ میں نشان لگے گا۔",
            style = MaterialTheme.typography.bodySmall
        )
        Text("قسم", style = MaterialTheme.typography.labelLarge)
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            EXPENSE_CATEGORIES.forEach { c ->
                FilterChip(selected = cat == c, onClick = { cat = c }, label = { Text(c) })
            }
        }
        Text("کس کا خرچ", style = MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SCOPES.forEach { s ->
                FilterChip(selected = sc == s, onClick = { sc = s }, label = { Text(s) })
            }
        }
        OutlinedTextField(
            value = limit,
            onValueChange = { limit = it.filter { c -> c.isDigit() } },
            label = { Text("ماہانہ حد (روپے)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )
        Button(onClick = {
            val lim = limit.toLongOrNull()
            if (lim == null || lim <= 0L) {
                toast(ctx, "حد درست لکھیں")
                return@Button
            }
            val existing = budgets.find { it.category == cat && it.scope == sc }
            scope.launch(Dispatchers.IO) {
                if (existing != null) {
                    dao.updateBudget(existing.copy(monthlyLimit = lim))
                } else {
                    dao.insertBudget(Budget(category = cat, scope = sc, monthlyLimit = lim))
                }
            }
            limit = ""
        }) { Text("محفوظ کریں") }
        budgets.forEach { b ->
            Card(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("${tr(b.category)} (${tr(b.scope)})")
                        Text(tr("ماہانہ حد") + ": " + Fmt.rupees(b.monthlyLimit), style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton(onClick = { scope.launch(Dispatchers.IO) { dao.deleteBudget(b) } }) { Text("حذف") }
                }
            }
        }

        Text("بچت کا ہدف", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(
            value = goalName,
            onValueChange = { goalName = it },
            label = { Text("ہدف کا نام، مثلاً نیا فون") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = goalTarget,
            onValueChange = { goalTarget = it.filter { c -> c.isDigit() } },
            label = { Text("کل رقم (روپے)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )
        Button(onClick = {
            val t = goalTarget.toLongOrNull()
            if (goalName.isBlank() || t == null || t <= 0L) {
                toast(ctx, "نام اور رقم درست لکھیں")
                return@Button
            }
            scope.launch(Dispatchers.IO) { dao.insertGoal(Goal(name = goalName.trim(), target = t)) }
            goalName = ""
            goalTarget = ""
        }) { Text("ہدف بنائیں") }
        goals.forEach { g ->
            val frac = if (g.target > 0L) (g.saved.toFloat() / g.target.toFloat()).coerceIn(0f, 1f) else 0f
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(g.name, style = MaterialTheme.typography.titleSmall)
                    Text("${Fmt.rupees(g.saved)} / ${Fmt.rupees(g.target)} (${(frac * 100).toInt()}%)")
                    Row {
                        TextButton(onClick = { addTo = g }) { Text("رقم جمع کریں") }
                        TextButton(onClick = { scope.launch(Dispatchers.IO) { dao.deleteGoal(g.id) } }) { Text("حذف") }
                    }
                }
            }
        }

        Text("ہر مہینے کے اندراجات", style = MaterialTheme.typography.titleMedium)
        Text(
            "مثلاً کرایہ یا بجلی کا بل۔ ہر مہینے خود بخود خرچ میں درج ہوگا۔",
            style = MaterialTheme.typography.bodySmall
        )
        OutlinedTextField(
            value = recName,
            onValueChange = { recName = it },
            label = { Text("نام، مثلاً کرایہ") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = recAmount,
            onValueChange = { recAmount = it.filter { c -> c.isDigit() } },
            label = { Text("رقم (روپے)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            EXPENSE_CATEGORIES.forEach { c ->
                FilterChip(selected = recCat == c, onClick = { recCat = c }, label = { Text(c) })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SCOPES.forEach { s ->
                FilterChip(selected = recScope == s, onClick = { recScope = s }, label = { Text(s) })
            }
        }
        Button(onClick = {
            val a = recAmount.toLongOrNull()
            if (recName.isBlank() || a == null || a <= 0L) {
                toast(ctx, "نام اور رقم درست لکھیں")
                return@Button
            }
            scope.launch(Dispatchers.IO) {
                dao.insertRecur(
                    Recurring(category = recCat, scope = recScope, amount = a, note = recName.trim())
                )
            }
            recName = ""
            recAmount = ""
        }) { Text("ہر مہینے شامل کریں") }
        recurring.forEach { r ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("${r.note} · ${tr(r.category)} (${tr(r.scope)})")
                        Text(Fmt.rupees(r.amount), style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton(onClick = { scope.launch(Dispatchers.IO) { dao.deleteRecur(r.id) } }) { Text("حذف") }
                }
            }
        }

        Text("فوری شارٹ کٹس", style = MaterialTheme.typography.titleMedium)
        if (presets.isEmpty()) Text("ابھی کوئی شارٹ کٹ نہیں۔ نیا اندراج بناتے وقت بنا سکتے ہیں۔")
        presets.forEach { p ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(p.name)
                        Text(
                            "${Fmt.rupees(p.amount)} · ${tr(p.category)} · ${tr(p.scope)} · ${tr(p.payment)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    TextButton(onClick = { scope.launch(Dispatchers.IO) { dao.deletePreset(p.id) } }) { Text("حذف") }
                }
            }
        }
    }

    addTo?.let { g ->
        AddToGoalDialog(goal = g, dao = dao, onDismiss = { addTo = null })
    }
}

@Composable
fun AddToGoalDialog(goal: Goal, dao: HisabDao, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var amt by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(goal.name) },
        text = {
            OutlinedTextField(
                value = amt,
                onValueChange = { amt = it.filter { c -> c.isDigit() } },
                label = { Text("جمع ہونے والی رقم (روپے)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
        },
        confirmButton = {
            TextButton(onClick = {
                val v = amt.toLongOrNull()
                if (v == null || v <= 0L) {
                    toast(ctx, "رقم درست لکھیں")
                    return@TextButton
                }
                scope.launch(Dispatchers.IO) {
                    dao.updateGoal(goal.copy(saved = goal.saved + v))
                }
                onDismiss()
            }) { Text("محفوظ کریں") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("منسوخ") }
        }
    )
}
