package com.hisab.app.ui

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.hisab.app.security.AppLock

fun canUseBio(ctx: Context): Boolean =
    BiometricManager.from(ctx).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) ==
        BiometricManager.BIOMETRIC_SUCCESS

fun showBio(activity: FragmentActivity) {
    val executor = ContextCompat.getMainExecutor(activity)
    val prompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
            AppLock.locked = false
        }
    })
    val info = BiometricPrompt.PromptInfo.Builder()
        .setTitle("حساب کتاب کھولیں")
        .setNegativeButtonText("PIN استعمال کریں")
        .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
        .build()
    prompt.authenticate(info)
}

@Composable
fun LockScreen() {
    val ctx = LocalContext.current
    val activity = ctx as FragmentActivity
    val bio = AppLock.bioOn() && canUseBio(ctx)
    var pin by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        if (bio) showBio(activity)
    }

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("حساب کتاب", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        Text("PIN درج کریں", style = MaterialTheme.typography.bodyMedium)
        Text(
            "●".repeat(pin.length) + "○".repeat(4 - pin.length),
            style = MaterialTheme.typography.headlineMedium
        )
        Text(msg, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(16.dp))

        val rows = listOf(
            listOf("1", "2", "3"),
            listOf("4", "5", "6"),
            listOf("7", "8", "9"),
            listOf(if (bio) "fp" else "", "0", "del")
        )
        rows.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { k ->
                    OutlinedButton(
                        onClick = {
                            if (k == "del") {
                                pin = pin.dropLast(1)
                            } else if (k == "fp") {
                                showBio(activity)
                            } else if (k.isNotEmpty() && pin.length < 4) {
                                pin += k
                                if (pin.length == 4) {
                                    if (AppLock.checkPin(pin)) {
                                        AppLock.locked = false
                                    } else {
                                        msg = "PIN غلط ہے"
                                        pin = ""
                                    }
                                }
                            }
                        },
                        enabled = k.isNotEmpty(),
                        modifier = Modifier.size(72.dp)
                    ) {
                        Text(
                            when (k) {
                                "del" -> "⌫"
                                "fp" -> "👆"
                                else -> k
                            }
                        )
                    }
                }
            }
        }
    }
}
