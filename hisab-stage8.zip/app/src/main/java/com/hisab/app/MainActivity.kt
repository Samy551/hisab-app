package com.hisab.app

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.fragment.app.FragmentActivity
import com.hisab.app.security.AppLock
import com.hisab.app.ui.HisabApp
import com.hisab.app.ui.Lang
import com.hisab.app.ui.LockScreen

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLock.init(this)
        Lang.init(this)
        setContent {
            Root()
        }
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) AppLock.onBackground()
    }
}

@Composable
fun Root() {
    val dark = isSystemInDarkTheme()
    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        if (AppLock.locked) LockScreen() else HisabApp()
    }
}
