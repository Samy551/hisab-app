package com.hisab.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.hisab.app.data.HisabDao
import com.hisab.app.data.HomeCash
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth

@Composable
fun HomeCashScreen(entries: List<HomeCash>, dao: HisabDao) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var ym by remember { mutableStateOf(YearMonth.now()) }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var person by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    val prefix = ym.toString()
    val month = entries.filter { it.date.startsWith(prefix) }
    val total = month.sumOf { it.amount }
    val byPerson = month.groupBy { it.person }
        .map { (p, l) -> p to l.sumOf { it.amount } }
        .sortedByDescending { it.second }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = { ym = ym.minusMonths(1) }) { Text("◀ پچھلا") }
            Text(prefix, style = MaterialTheme.typography.titleMedium)
            TextButton(onClick = { ym = ym.plusMonths(1) }) { Text("اگلا ▶") }
        }

        Text("گھر میں نقد دینا", style = MaterialTheme.typography.titleMedium)
        Text(
            "گھر کے خرچ کے لیے جو نقد دیا جائے، وہ یہاں درج کریں۔",
            style = MaterialTheme.typography.bodySmall
        )

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("اس مہینے گھر میں دیا گیا نقد")
                Text(Fmt.rupees(total), style = MaterialTheme.typography.headlineSmall)
                byPerson.forEach { (p, a) ->
                    Text("$p: ${Fmt.rupees(a)}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        Text("نیا اندراج", style = MaterialTheme.typography.labelLarge)
        OutlinedTextField(
            value = date,
            onValueChange = { date = it },
            label = { Text("تاریخ (مثلاً 2026-11-24)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = person,
            onValueChange = { person = it },
            label = { Text("کس کو دیا، مثلاً امی، بیوی") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = amount,
            onValueChange = { amount = it.filter { c -> c.isDigit() } },
            label = { Text("رقم (روپے)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = note,
            onValueChange = { note = it },
            label = { Text("نوٹ (اختیاری)") },
            modifier = Modifier.fillMaxWidth()
        )
        Button(onClick = {
            val d = runCatching { LocalDate.parse(date.trim()).toString() }.getOrNull()
            val amt = amount.trim().toLongOrNull()
            val name = person.trim()
            if (d == null) {
                toast(ctx, "تاریخ درست لکھیں، مثلاً 2026-11-24")
                return@Button
            }
            if (name.isEmpty() || amt == null || amt <= 0L) {
                toast(ctx, "نام اور رقم درست لکھیں")
                return@Button
            }
            val entry = HomeCash(date = d, amount = amt, person = name, note = note.trim())
            scope.launch(Dispatchers.IO) { dao.insertHomeCash(entry) }
            toast(ctx, "محفوظ ہو گیا")
            person = ""
            amount = ""
            note = ""
        }) { Text("محفوظ کریں") }

        Text("فہرست", style = MaterialTheme.typography.labelLarge)
        if (month.isEmpty()) Text("اس مہینے گھر میں نقد نہیں دیا گیا")
        month.forEach { h ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(h.person, style = MaterialTheme.typography.titleSmall)
                        Text(Fmt.rupees(h.amount))
                    }
                    Text(h.date, style = MaterialTheme.typography.bodySmall)
                    if (h.note.isNotBlank()) Text(h.note, style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { scope.launch(Dispatchers.IO) { dao.deleteHomeCash(h.id) } }) {
                        Text("حذف")
                    }
                }
            }
        }
    }
}
