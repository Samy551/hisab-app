package com.hisab.app.data

import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import com.hisab.app.ui.Fmt
import java.time.YearMonth

object Report {
    private class Line(val text: String, val bold: Boolean)

    fun write(ctx: Context, uri: Uri, ym: YearMonth, items: List<Tx>, budgets: List<Budget>): Boolean {
        val prefix = ym.toString()
        val month = items.filter { it.date.startsWith(prefix) }.sortedBy { it.date }
        val income = month.filter { it.isIncome }.sumOf { it.amount }
        val expense = month.filter { !it.isIncome }.sumOf { it.amount }

        val lines = mutableListOf<Line>()
        lines.add(Line("حساب کتاب - $prefix", true))
        lines.add(Line("آمدن: ${Fmt.rupees(income)}", false))
        lines.add(Line("خرچ: ${Fmt.rupees(expense)}", false))
        lines.add(Line("باقی بچت: ${Fmt.rupees(income - expense)}", false))
        lines.add(Line("", false))

        lines.add(Line("خرچ کی قسم کے لحاظ سے", true))
        month.filter { !it.isIncome }
            .groupBy { it.category }
            .map { (c, l) -> c to l.sumOf { it.amount } }
            .sortedByDescending { it.second }
            .forEach { (c, a) -> lines.add(Line("$c: ${Fmt.rupees(a)}", false)) }
        lines.add(Line("", false))

        if (budgets.isNotEmpty()) {
            lines.add(Line("ماہانہ بجٹ", true))
            budgets.forEach { b ->
                val spent = month.filter { !it.isIncome && it.category == b.category && it.scope == b.scope }
                    .sumOf { it.amount }
                val flag = if (spent > b.monthlyLimit) " (حد سے زیادہ)" else ""
                lines.add(Line("${b.category} (${b.scope}): ${Fmt.rupees(spent)} / ${Fmt.rupees(b.monthlyLimit)}$flag", false))
            }
            lines.add(Line("", false))
        }

        lines.add(Line("تمام اندراجات", true))
        if (month.isEmpty()) lines.add(Line("اس مہینے کوئی اندراج نہیں", false))
        month.forEach { t ->
            val sign = if (t.isIncome) "+" else "-"
            val note = if (t.note.isBlank()) "" else " | ${t.note}"
            lines.add(
                Line(
                    "${t.date} | ${t.category} | ${t.scope} | ${t.payment ?: "کیش"} | $sign${Fmt.rupees(t.amount)}$note",
                    false
                )
            )
        }

        val pageW = 595
        val pageH = 842
        val lh = 18f
        val perPage = ((pageH - 80) / lh).toInt()
        val regular = Paint().apply {
            isAntiAlias = true
            textSize = 11f
            textAlign = Paint.Align.RIGHT
        }
        val bold = Paint(regular).apply {
            isFakeBoldText = true
            textSize = 14f
        }

        val doc = PdfDocument()
        try {
            var pageNo = 1
            lines.chunked(perPage).forEach { chunk ->
                val page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
                val c = page.canvas
                var y = 50f
                chunk.forEach { ln ->
                    c.drawText(ln.text, pageW - 40f, y, if (ln.bold) bold else regular)
                    y += lh
                }
                doc.finishPage(page)
                pageNo++
            }
            if (lines.isEmpty()) {
                val page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, 1).create())
                doc.finishPage(page)
            }
            val out = ctx.contentResolver.openOutputStream(uri) ?: return false
            out.use { doc.writeTo(it) }
            return true
        } catch (e: Exception) {
            return false
        } finally {
            doc.close()
        }
    }
}
